import static java.lang.System.out;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class Irene {

	public static void main(String[] args) throws IOException {
		Scanner file = new Scanner(new File("irene.dat"));
		int numOfNums = file.nextInt();
		for (int i = 1; i <= numOfNums; i++) {
			int value = file.nextInt();
			out.println(value + " " + classifyNum(value));
		}
	}

	public static boolean isPrime(int x) {
		for (int k = 2; k <= Math.sqrt(x); k++)
			if (x % k == 0)
				return false;
		return true;
	}

	public static String classifyNum(int val) {
		String temp = "";
		if (isPrime(val))
			temp = "NOT SEMIPRIME";
		else
			for (int factor = 2; factor < val; factor++) {
				if (val % factor == 0)
					if (!isPrime(factor))
						temp = "NOT SEMIPRIME";
					else {
						int other_factor = val / factor;
						if (!isPrime(other_factor))
							temp = "NOT SEMIPRIME";
						else if (factor == other_factor)
							temp = "SEMIPRIME";
						else
							temp = "DISCRETE SEMIPRIME";
					}
			}

		return temp;
	}

}
