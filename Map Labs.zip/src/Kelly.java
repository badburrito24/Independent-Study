import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Kelly {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner s = new Scanner(new File("kelly.dat"));
		String alphabet = " ABCDEFGHIJLMNOPQRSTUVWXYZ";
		while (s.hasNext()) {
			Scanner nums = new Scanner(s.nextLine());
			while (nums.hasNextInt()) {
				int r = nums.nextInt();
				int c = nums.nextInt();
				if (r == 0)
					System.out.print(' ');
				else
					System.out.print(alphabet.charAt((r - 1) * 5 + c));
			}
			System.out.println();
			nums.close();
		}
		s.close();
	}
}
